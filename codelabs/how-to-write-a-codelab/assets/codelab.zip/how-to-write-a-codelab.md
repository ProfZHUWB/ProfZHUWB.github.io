﻿summary: 用 Codelab 写教程
id: how-to-write-a-codelab
categories: Writing
tags: medium
status: Published 
authors: Prof. Wenbin Zhu
Feedback Link: https://ProfZhuWB.gitee.com/how-to-write-a-codelab


# 用 Codelab 写教程

<!-- ------------------------ -->
## 概览 
Duration: 1

### 你将学会 
- Google Codelab 的优势 
- 如何用 claat 离线工具把 Codelab 转换成静态 html 文件 
- 如何发布生成的 html 文件
- 如何用 markdown 文件写一个 Codelab 


<!-- ------------------------ -->
## Google Codelabs 的优势
Duration: 1

### Google Codelabs [首页](https://codelabs.developers.google.com/) 有很多教程
![alt-text-here](how-to-write-a-codelab-assets/fig1-google-codelabs.png)

### 一个互动教程[例子](https://codelabs.developers.google.com/codelabs/cloud-tensorflow-mnist/index.html?index=..%2F..index#0)
![alt-text-here](how-to-write-a-codelab-assets/fig1-google-codelabs-eg1.png)

Negative
: Codelab 本身不支持嵌入 latex 公式

<!-- ------------------------ -->
## 创作 Codelab 的流程

1. 到 [官方](https://github.com/googlecodelabs/tools/releases/tag/v2.2.0) 适合你系统的版本，比如 [claat-windows-amd64.exe](https://github.com/googlecodelabs/tools/releases/download/v2.2.0/claat-windows-amd64.exe) ，保存为 claat.exe

2. 按照 [这个格式](https://github.com/googlecodelabs/tools/blob/master/FORMAT-GUIDE.md) 用任意文本编辑器比如 notepad 写一个文件保存为 **\*.md** ，用utf-8编码保存避免中文出现乱码。文件开头的 **id:** 后是保存生成的 html 文件的目录

3. 运行 claat 命令生成 html 文件：claat export 文件名.md

4. 运行 claat serve 命令在本机 9090 端口开启一个网页服务器，并自动开启默认浏览器。在默认浏览器中点击 how-to-write-a-codelab 浏览效果。

5. 把生成的 how-to-write-a-codelab/ 目录整个上传 gitee.com 用 pages 服务发布即可给国内用户浏览。也可以上传 github.com 国内用户需要翻墙浏览

Negative
: claat 需要调用 Google 的 codelabs-preview 服务，所以需要有一个 Goolge 账号，并已经用 Chrome 登录才能使用

Positive
: claat 生成的是静态 html 文件，用到 http://*.googleapis.com 资源不需要翻墙就可以使用


<!-- ------------------------ -->
## 离线写作：使用本教程的例子
Duration: 2

### 1. 下载例子源码

[下载](how-to-write-a-codelab-assets/codelab.zip)本教程的源文件，压缩到一个目录比如 C:\codelab。可以看到以下文件

| 文件 | 描述 |
| --- | --- |
| claat.exe | claat-windows-amd64.exe [2.2.0 版本](https://github.com/googlecodelabs/tools/releases/download/v2.2.0) |
| how-to-write-a-codelab-assets | 本教程用到的图片资源文件，会自动复制到生成的目录下 |
| assets | 本教程用到的其他文件，比如 zip，需要手动复制到生成的目录下 |
| how-to-write-a-codelab.md | 本教程的 markdown 文件 |


### 2. 用 claat 生成 html 文件

打开 cmd 命令行窗口，并进 c:\codelab 目录，运行 claat.exe 生成 html 文件
```console
c:\codelab> claat.exe export how-to-write-a-codelab.md
ok      how-to-write-a-codelab
```
成功生成 html 文件并保存在 how-to-write-a-codelab 目录下。

Positive
: \*.md 文件里面引用到所有本地图片都会复制到生成的目录下的 img 子目录，并且把涉及到的链接都修改到正确位置。

Negative
: \*.md 文件里面引用到的非图片，比如 zip 文件，需要手段复制到生成的目录下。建议把这类文件存在 assets 子目录，
然后把整个子目录复制到生成的目录下。

### 3. 启动网页服务器测试生成的 html 文件

在命令行运行 claat serve：
```console
c:\codelab> claat serve
Serving codelabs on localhost:9090, opening browser tab now...
```

Claat 会自动打开系统默认浏览器

![预览](how-to-write-a-codelab-assets/fig2-browser.png)

在打开的浏览器内点击 how-to-write-a-codelab 目录

![预览](how-to-write-a-codelab-assets/fig2-preview.png)


### 4. 如果 Claat 无法启动网页服务器

Claat 默认使用 9090 端口，如果该端口已经被占用会出现以下错误
```console
c:\codelab> claat.exe serve
Serving codelabs on localhost:9090, opening browser tab now...
claat serve: listen tcp 127.0.0.1:9090: bind: Only one usage of each socket address (protocol/network address/port) is normally permitted.
```

可以用 -addr 指定一个不同的端口，比如 9999
```console
c:\codelab> claat.exe serve -addr localhost:9999
Serving codelabs on localhost:9999, opening browser tab now...
```

在命令窗口输入 Ctrl + C 可以停止 claat serve 开启的服务器。如果没有反应，多按几次 Ctrl + C


### 5. 如果默认浏览器（如 Microsoft Edge）无法正常显示

试过用系统默认的 Microsoft Edge 浏览器打开时，Codelab 左手边的菜单不见了。翻墙之后可以正常显示。正常显示过一次后，每次不用翻墙也可以正常显示。用 Chrome 打开，不翻墙好像也可以正常显示。


<!-- ------------------------ -->
## 用在线 latex 编辑器编辑数学公式
Duration: 2

1. 用 Chrome 或者 Microsoft Edge 浏览器打开 [在线编辑器](https://www.codecogs.com/latex/eqneditor.php)
2. 在下图红色的代码框中输入 latex 公式，在代码框下面会看到公式
3. 绿色下拉框处选择合适的格式，如果要在网站发布可以用 png 格式
4. 如果公式不够清晰，可以在紫色下拉框选更高分辨率
5. 点公式下方（浅蓝色圈内的) Click here to Download 链接下载并保存图片
6. 把图片嵌入到自己的网页中 

![预览](how-to-write-a-codelab-assets/fig3-online-latex-editor.png)

Positive
: [常用 Latex 数学符号](https://oeis.org/wiki/List_of_LaTeX_mathematical_symbols)



<!-- ------------------------ -->
## 用 gitee.io 的个人网站功能发布
Duration: 2

1. 去 [码云](https://gitee.com/) 注册一个免费账号，比如 **ProfZhuWB**，需要绑定手机号码才能使用个人网站功能
2. 登录后创建一个与账号同名的仓库，比如 **ProfZhuWB**
3. 用 git 客户端比如 TortoiseGit 把创建的空仓库 clone 到本地，比如 d:\git-ivan\ProfZhuWB.git
4. 把个人网站的内容，比如 how-to-write-a-codelab 整个目录放入本地仓库比如，d:\git-ivan\ProfZhuWB.git
5. 用 git 客户端 commit, 并把更新的内容 push 到 gitee.com
6. 在浏览器地址栏输入 https://gitee.com/ProfZhuWB/ProfZhuWB/pages 去到 Pages 服务页面。
    * 勾选页面左下角的 Enforce HTTPS 选项
    * 点击页面左下角的 Create 按钮
7. 把链接 https://ProfZhuWB.gitee.io/codelabs/how-to-write-a-codelab/ 发给朋友

Negative
: 每次把本地仓库的内容推送到 gitee.com 以后都要在 Pages 服务页面按左下角的 Update 按钮，更新后的内容才会发布给公众。 

